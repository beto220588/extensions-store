from __future__ import annotations


def activate(context):
    print("Office Helper activada")
    return {
        "id": "office-helper",
        "name": "Office Helper",
        "status": "ready",
        "message": "Paquete instalable preparado para activacion manual.",
    }

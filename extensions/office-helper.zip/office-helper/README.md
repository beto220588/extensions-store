# Office Helper

Paquete instalable de prueba para la tienda remota de extensiones internas del navegador.

## Categoria

Productividad

## Descripcion

Guarda y exporta contenido web a PDF, Word, TXT, Markdown, HTML e imagen.

## Permisos declarados

- `tabs`
- `downloads`
- `filesystem`
- `capture`

## Notas

- Este paquete no ejecuta codigo automaticamente al instalarse.
- La entrada principal esta en `src/extension.py`.
- Fue preparado para pruebas de instalacion local/remota y catalogo seguro.

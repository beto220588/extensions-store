def activate(context):
    print("Test Extension activada")
